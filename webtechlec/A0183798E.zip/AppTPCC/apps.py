from django.apps import AppConfig


class ApptpccConfig(AppConfig):
    name = 'AppTPCC'
